package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.EmployNotFoundException;
import com.example.demo.model.Employ;
import com.example.demo.repo.EmployRepository;

@Service
public class EmployService {

	
	@Autowired
	private EmployRepository repo;
	
	public List<Employ> showEmploy()
	{
		return repo.findAll();
	}
	
	public Employ searchEmploy(int empno)
	{
		return repo.findById(empno).orElseThrow(() -> new EmployNotFoundException("Employ not found..."));
	}
	
	public String addEmploy(Employ employ)
	{
		repo.save(employ);
		return "Employ Record Inserted";
	}
	
	public String updateEmploy(Employ employ)
	{
		repo.save(employ);
		return "Employ Record Updated";
	}
	
	public String deleteEmploy(int empno)
	{
		Employ employ=searchEmploy(empno);
		repo.delete(employ);
		return "Employ record deleted successfully";
	}

	
	
	public List<Employ> showByGender(String gender)
	{
		return repo.findByDept(gender);
	}
	
	public List<Employ> showByDept(String dept)
	{
		return repo.findByDept(dept);
	}
	
	public List<Employ> showByDeptAndGender(String dept,String gender)
	{
		return repo.findByDeptAndGender(dept,gender);
	}
	
}
