package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employ;
import com.example.demo.service.EmployService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping(value="/employ")
public class EmployController {

	
	@Autowired
	private EmployService employService;
	
	@GetMapping(value="/showemploy")
	public ResponseEntity<List<Employ>> showEmploy()
	{
		return ResponseEntity.ok(employService.showEmploy());
	}
	@GetMapping(value="/searchemploy/{empno}")
	public  ResponseEntity<Employ >searchEmploy(@PathVariable int empno){
	      return ResponseEntity.ok(employService.searchEmploy(empno));                        
	}
 
	@PutMapping(value="/updateemploy")
	public ResponseEntity<String> updateEmploy(@PathVariable Employ employ)
	{
		String update=employService.updateEmploy(employ);
		return ResponseEntity.ok(update);
	}
	
	
	@PostMapping(value="/addemploy")
	public ResponseEntity<String> addEmploy(@RequestBody Employ employ){
		String saved = employService.addEmploy(employ);
	      return new ResponseEntity<>(saved, HttpStatus.CREATED);                        
	}
	
	
	@GetMapping(value="/showByGender/{gender}")
	public ResponseEntity<List<Employ>> showByGender(@PathVariable String gender)
	{
		return ResponseEntity.ok(employService.showByGender(gender));
	}
	
	@GetMapping(value="/showByDept/{dept}")
	public ResponseEntity<List<Employ>> showByDept(@PathVariable String dept)
	{
		return ResponseEntity.ok(employService.showByDept(dept));
	}
	@GetMapping(value="/showByDeptAndGender/{dept}/{gender}")
	public ResponseEntity<List<Employ>> showByDeptAndGender(@PathVariable String dept , @PathVariable String gender)
	{
		return ResponseEntity.ok(employService.showByDeptAndGender(dept,gender));
	}
}
