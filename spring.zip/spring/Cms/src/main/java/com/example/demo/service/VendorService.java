package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Vendor;
import com.example.demo.repo.VendorRepository;

@Service
public class VendorService {

	@Autowired
	private VendorRepository vendorRepository;

	public String loginVendor(String user, String pwd) {
		Vendor vendor= vendorRepository.findByVenUserNameAndVenPassword(user, pwd);
		if (vendor!=null) {
			return "1";
		}
		return "0";
	}
	public Vendor searchByuserName(String user) {
		Vendor vendor = vendorRepository.findByVenUserName(user);
		System.out.println("Vendor  " +vendor);
		return vendor;
		
	}
	
	public List<Vendor> showVendor() {
		return vendorRepository.findAll();
	}
	
	public Vendor searchByVendorId(int id) {
		return vendorRepository.findById(id).get();
	}

}