package com.example.demo.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity 
@Table(name="Vendor")
public class Vendor {

	    @Id
		@Column(name="VEN_ID")
		private int venId;
		@Column(name="VEN_NAME")
		private String venName;
		@Column(name="VEN_NUMBER")
		private String venNo;
		@Column(name="VEN_USER_NAME")
		private String venUserName;
		@Column(name="VEN_PASSWORD")
		private String venPassword;
		@Column(name="VEN_EMAIL")
		private String venEmail;
		@Column(name="VEN_ADDRESS")
		private String venAddress;
		public int getVenId() {
			return venId;
		}
		public void setVenId(int venId) {
			this.venId = venId;
		}
		public String getVenName() {
			return venName;
		}
		public void setVenName(String venName) {
			this.venName = venName;
		}
		public String getVenNo() {
			return venNo;
		}
		public void setVenNo(String venNo) {
			this.venNo = venNo;
		}
		public String getVenUserName() {
			return venUserName;
		}
		public void setVenUserName(String venUserName) {
			this.venUserName = venUserName;
		}
		public String getVenPassword() {
			return venPassword;
		}
		public void setVenPassword(String venPassword) {
			this.venPassword = venPassword;
		}
		public String getVenEmail() {
			return venEmail;
		}
		public void setVenEmail(String venEmail) {
			this.venEmail = venEmail;
		}
		public String getVenAddress() {
			return venAddress;
		}
		public void setVenAddress(String venAddress) {
			this.venAddress = venAddress;
		}
		
		
}
