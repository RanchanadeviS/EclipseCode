package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employRepository;

//	public String loginEmploy(int empId) {
//		Employ employ = customerRepository.findByEmpId(empId);
//		if (employ!=null) {
//			return "1";
//		}
//		return "0";
//	}
//	public Customer searchByuserName(String user) {
//		Customer customer = customerRepository.findByCusUserName(user);
//		System.out.println("Customer  " +customer);
//		return customer;
//		
//	}
//	
	public List<Employee> showEmploy() {
		return employRepository.findAll();
	}
//	
//	public Customer searchByCustomerId(int id) {
//		return customerRepository.findById(id).get();
//	}

}