package com.example.demo.model;



import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Employee")   // table name as in DB
public class Employee {

    @Id
    @Column(name = "EmpId")   // EXACT column name
    private Integer empId;

    @Column(name = "EmpName")
    private String empName;

    @Column(name = "EmpEmail")
    private String empEmail;

    @Column(name = "MobileNo")
    private String mobileNo;

    @Column(name = "DateOfJoin")
    private LocalDate dateOfJoin;

    @Column(name = "ManagerId")
    private Integer managerId;

    @Column(name = "LeaveAvail")
    private Integer leaveAvail;

    // Getters & Setters

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpEmail() {
        return empEmail;
    }

    public void setEmpEmail(String empEmail) {
        this.empEmail = empEmail;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public LocalDate getDateOfJoin() {
        return dateOfJoin;
    }

    public void setDateOfJoin(LocalDate dateOfJoin) {
        this.dateOfJoin = dateOfJoin;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public Integer getLeaveAvail() {
        return leaveAvail;
    }

    public void setLeaveAvail(Integer leaveAvail) {
        this.leaveAvail = leaveAvail;
    }
}

//import java.sql.Date;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//
//
//
//@Entity 
//@Table(name="Employee")
//public class Employee {
//	
////
//	@Id
//	@Column(name="EmpId")
//	private int emp_id;
//	@Column(name="EmpName")
//	private String emp_name;
//	@Column(name="EmpEmail")
//	private String emp_email;
//	@Column(name="MobileNo")
//	private String mobile_no;
//	@Column(name="DateOfJoin")
//	private Date date_of_join;
//	@Column(name="ManagerId")
//	private String manager_id;
//	@Column(name="LeaveAvail")
//	private Date leave_avail;
//	public int getEmpId() {
//		return emp_id;
//	}
//	public void setEmpId(int emp_id) {
//		this.emp_id = emp_id;
//	}
//	public String getEmpName() {
//		return emp_name;
//	}
//	public void setEmpName(String emp_name) {
//		this.emp_name = emp_name;
//	}
//	public String getEmpEmail() {
//		return emp_email;
//	}
//	public void setEmpEmail(String emp_email) {
//		this.emp_email = emp_email;
//	}
//	public String getMobileNo() {
//		return mobile_no;
//	}
//	public void setMobileNo(String mobile_no) {
//		this.mobile_no = mobile_no;
//	}
//	public Date getDateOfJoin() {
//		return date_of_join;
//	}
//	public void setDateOfJoin(Date date_of_join) {
//		this.date_of_join = date_of_join;
//	}
//	public String getManagerId() {
//		return manager_id;
//	}
//	public void setManagerId(String manager_id) {
//		this.manager_id = manager_id;
//	}
//	public Date getLeaveAvail() {
//		return leave_avail;
//	}
//	public void setLeaveAvail(Date leave_avail) {
//		this.leave_avail = leave_avail;
//	}
//    
//	
//	
//	
//	
//	
////	@Id
////	@Column(name="EmpId")
////	private int empId;
////	@Column(name="EmpName")
////	private String empName;
////	@Column(name="EmpEmail")
////	private String empEmail;
////	@Column(name="MobileNo")
////	private String mobileNo;
////	@Column(name="DateOfJoin")
////	private Date dateOfJoin;
////	@Column(name="ManagerId")
////	private String managerId;
////	@Column(name="LeaveAvail")
////	private Date leaveAvail;
////	public int getEmpId() {
////		return empId;
////	}
////	public void setEmpId(int empId) {
////		this.empId = empId;
////	}
////	public String getEmpName() {
////		return empName;
////	}
////	public void setEmpName(String empName) {
////		this.empName = empName;
////	}
////	public String getEmpEmail() {
////		return empEmail;
////	}
////	public void setEmpEmail(String empEmail) {
////		this.empEmail = empEmail;
////	}
////	public String getMobileNo() {
////		return mobileNo;
////	}
////	public void setMobileNo(String mobileNo) {
////		this.mobileNo = mobileNo;
////	}
////	public Date getDateOfJoin() {
////		return dateOfJoin;
////	}
////	public void setDateOfJoin(Date dateOfJoin) {
////		this.dateOfJoin = dateOfJoin;
////	}
////	public String getManagerId() {
////		return managerId;
////	}
////	public void setManagerId(String managerId) {
////		this.managerId = managerId;
////	}
////	public Date getLeaveAvail() {
////		return leaveAvail;
////	}
////	public void setLeaveAvail(Date leaveAvail) {
////		this.leaveAvail = leaveAvail;
////	}
//	
//	
//	
//}
