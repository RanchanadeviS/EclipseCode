package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Vendor;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Integer> {
	Vendor findByVenUserName(String venUserName);
	Vendor findByVenUserNameAndVenPassword(String user, String pwd);

}