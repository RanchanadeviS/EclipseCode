package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Vendor;
import com.example.demo.service.VendorService;



@RestController
public class VendorController {



		@Autowired
		private VendorService vendorService;
		
		@GetMapping(value="/showvendor")
		public ResponseEntity<List<Vendor>> showVendor() {
			return ResponseEntity.ok(vendorService.showVendor());
		}
		
		@GetMapping(value="/vendorlogin/{user}/{pwd}")
		public ResponseEntity<String> login(
				@PathVariable
				String user, @PathVariable String pwd) {
			return ResponseEntity.ok(
		            vendorService.loginVendor(user, pwd)
		    );
		}
		
		@GetMapping(value="/searchvendor/{id}")
		public ResponseEntity<Vendor> searchByVendorId(@PathVariable int id) {
			return ResponseEntity.ok(vendorService.searchByVendorId(id));
		}
		
		@GetMapping(value="/vendoruser/{user}")
		public ResponseEntity<Vendor> customerUser(@PathVariable String user) {
			return ResponseEntity.ok(vendorService.searchByuserName(user));
		}
}
