package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="Agent")
public class Agent {
	 
	  @Id
	  @Column(name="agentid")
	  private int agentid;
	  @Column(name="name")
	  private String name;
	  @Column(name="city")
	  private String city;
	  @Column(name="gender")
	  private String gender;
	  @Column(name="maritalstatus")
	  private int maritalstatus;
	  @Column(name="premium ")
	  private double  premium ;
	  public int getAgentid() {
		  return agentid;
	  }
	  public void setAgentId(int agentid) {
		  this.agentid = agentid;
	  }
	  public String getName() {
		  return name;
	  }
	  public void setName(String name) {
		  this.name = name;
	  }
	  public String getCity() {
		  return city;
	  }
	  public void setCity(String city) {
		  this.city = city;
	  }
	  public String getGender() {
		  return gender;
	  }
	  public void setGender(String gender) {
		  this.gender = gender;
	  }
	  public int getMaritalStatus() {
		  return maritalstatus;
	  }
	  public void setMaritalStatus(int maritalstatus) {
		  maritalstatus = maritalstatus;
	  }
	  public double getPremium() {
		  return premium;
	  }
	  public void setPremium(double premium) {
		  this.premium = premium;
	  }
	  @Override
	  public String toString() {
		return "Agent [agentId=" + agentid + ", name=" + name + ", city=" + city + ", gender=" + gender
				+ ", MaritalStatus=" + maritalstatus + ", premium=" + premium + "]";
	  }
	  public Agent(int agentid, String name, String city, String gender, int maritalstatus, double premium) {
		super();
		this.agentid = agentid;
		this.name = name;
		this.city = city;
		this.gender = gender;
		maritalstatus = maritalstatus;
		this.premium = premium;
	  }
	  public Agent() {
		super();
		// TODO Auto-generated constructor stub
	  }
	  
	  
	  

}
