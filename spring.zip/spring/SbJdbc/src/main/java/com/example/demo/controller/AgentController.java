package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Agent;
import com.example.demo.model.Employ;
import com.example.demo.service.AgentService;
import com.example.demo.service.EmployService;

@RestController
@RequestMapping(value="/agent")
public class AgentController {

	@Autowired
	private AgentService agentservice;
	
	@GetMapping(value="/showagent")
	public List<Agent> showAgent()
	{
		return agentservice.showAgent();
	}
	
	@GetMapping(value="/searchagent/{agentid}")
	public Agent searchAgent(@PathVariable int agentid)
	{
		return agentservice.searchAgent(agentid);
	}
	
	
	@PutMapping(value="/updateagent")
	public String updateAgent(@RequestBody Agent agent)
	{
		return agentservice.updateAgent(agent);
	}
	
	@PostMapping(value="/addagent")
	public String addAgent(@RequestBody Agent agent)
	{
		return agentservice.addAgent(agent);
	}

	
	@DeleteMapping(value="/deleteagent/{agentid}")
	public String deletAgent(@PathVariable int agentid)
	{
		return agentservice.deleteAgent(agentid);
	}
}