package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Agent;
import com.example.demo.repo.AgentRepository;


@Service
public class AgentService {

	
	@Autowired
	private AgentRepository repo;
	
	public List<Agent> showAgent()
	{
		return repo.findAll();
	}
	
	public Agent searchAgent(int agentid)
	{
		return repo.findById(agentid).get();
	}
	
	public String addAgent(Agent agent)
	{
		repo.save(agent);
		return "Agent Record Inserted";
	}
	
	public String updateAgent(Agent agent)
	{
		repo.save(agent);
		return "Agent Record Updated";
	}
	
	public String deleteAgent(int agentid)
	{
		Agent agent=searchAgent(agentid);
		repo.delete(agent);
		return "Agent record deleted successfully";
	}
}