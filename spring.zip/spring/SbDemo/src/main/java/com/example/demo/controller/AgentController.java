package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Agent;
import com.example.demo.service.AgentService;

import ch.qos.logback.core.model.Model;


@Controller
public class AgentController {

    @Autowired
    private AgentService agentService;
//
//    @GetMapping("/addagent")
//    public String addNewEmployee(Model model) {
//        Agent agent = new Agent();
//        model.addAttribute("agent",agent);
//        return "addagent";
//    }
//
//    @PostMapping("/savenew")
//    public String saveAgent(@ModelAttribute("agent") Agent agent) {
//    	agentService.addAgent(agent);
//        return "redirect:/";
//    }
//
//    
//    @PostMapping("/saveagent")
//    public String saveEmployee(@ModelAttribute("agent") 
//    Agent agent) {
//    	agentService.updateAgent(agent);
//        return "redirect:/";
//    }
//
//    @GetMapping(value="/updateform/{empno}")
//    public String updateForm(@PathVariable(value="agentid") int agentid,
//    		Model model
//    		) {
//    	Agent agent= agentService.searchAgent(agentid);
//    	model.addAttribute(agent);
//    	return "updateform";
//    }
//    
//    @GetMapping(value="/deleteemploy/{empno}")
//    public String deleteemploy(@PathVariable(value="agentid") int agentid
//    		) {
//    	agentService.deleteAgent(agentid);
//    	return "redirect:/";
//    }
   
    @GetMapping("/")
    public String showAgent(org.springframework.ui.Model model) {
        List<Agent> agentList = agentService.showAgent();
        model.addAttribute("agentList", agentList);
        return "agentshow";   // employshow.html
    }
}