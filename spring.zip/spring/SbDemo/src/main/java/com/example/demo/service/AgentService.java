package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.AgentNotFoundException;
import com.example.demo.model.Agent;

import com.example.demo.repo.AgentRepository;



@Service
public class AgentService {

	@Autowired
	private AgentRepository repo;
	
	public Agent searchAgent(int agentid) {
	    return repo.findById(agentid)
	            .orElseThrow(() -> new AgentNotFoundException("agent No Not Found..."));
	}
	
	public String deleteAgent(int agentid) {
		Agent agent = searchAgent(agentid);
		repo.delete(agent);
		return "agent Record Deleted...";
	}
	
	public String updateEmploy(Agent agent) {
		repo.save(agent);
		return "agent Record Updated...";
	}
	
	public String addEmploy(Agent agent) {
		repo.save(agent);
		return "agent Record Inserted...";
	}
	
	
	
	public List<Agent> showAgent() {
		return repo.findAll();
	}
}