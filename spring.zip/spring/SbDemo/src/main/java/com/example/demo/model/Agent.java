package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="Agent")
public class Agent {
	 
	  @Id
	  private int agentid;
	  private String name;
	  private String city;
	  private String gender;
	  private int maritalstatus;
	  private double  premium ;
	  public int getAgentid() {
		  return agentid;
	  }
	  public void setAgentId(int agentid) {
		  this.agentid = agentid;
	  }
	  public String getName() {
		  return name;
	  }
	  public void setName(String name) {
		  this.name = name;
	  }
	  public String getCity() {
		  return city;
	  }
	  public void setCity(String city) {
		  this.city = city;
	  }
	  public String getGender() {
		  return gender;
	  }
	  public void setGender(String gender) {
		  this.gender = gender;
	  }
	  public int getMaritalStatus() {
		  return maritalstatus;
	  }
	  public void setMaritalStatus(int maritalstatus) {
		  maritalstatus = maritalstatus;
	  }
	  public double getPremium() {
		  return premium;
	  }
	  public void setPremium(double premium) {
		  this.premium = premium;
	  }
	 
	  
	  
	  

}
