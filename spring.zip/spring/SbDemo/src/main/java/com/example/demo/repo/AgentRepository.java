package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Agent;


@Repository
public interface AgentRepository 
	extends JpaRepository<Agent, Integer> {
//	List<Agent>  findByGender(String gender);
//	List<Agent> findByDept(String dept);
//	List<Agent> findByDeptAndGender(String dept, String gender);
}