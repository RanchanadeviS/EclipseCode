package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/calc")
public class CalcController {
	
	
	@GetMapping("/sum/{i}/{j}")
	public int Sum(@PathVariable int i,@PathVariable int j)
	{
		return i+j;
	}
	@GetMapping("/sub/{i}/{j}")
	public int Sub(@PathVariable int i,@PathVariable int j)
	{
		return i-j;
	}
	@GetMapping("/mul/{i}/{j}")
	public int Mul(@PathVariable int i,@PathVariable int j)
	{
		return i*j;
	}
	@GetMapping("/div/{i}/{j}")
	public int Div(@PathVariable int i,@PathVariable int j)
	{
		return i/j;
	}

}
