package com.example.demo.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;


@Service
public class CustomerDao {
	
	 private static List<Customer> customerList =
		        new ArrayList<>(
		            Arrays.asList(
		                new Customer(1,"Ranchana","karur","7894561233",1000),
		                new Customer(2,"Sumi","chennai","8220635430",3000),
		                new Customer(3,"Sakthivel","karur","9525645235",9000),
		                new Customer(4,"Kumuthavalli","karur","7894561233",10000),
		                new Customer(5,"Poorni","Madurai","963258741",15000),
		                new Customer(6,"Ranch","chennai","852147963",1000)
		            )
		        );
	 
	 
	 public List<Customer> showCustomer() {
		// TODO Auto-generated method stub
		return customerList;
	 }
	 
	 
	 public Customer searchCustomer(int custId) {
			return customerList.stream()
			        .filter(e -> e.getCustId() == custId)
			        .findFirst()
			        .orElse(null);
		}
	 
	 
	 public String updateCustomer(Customer customer) {
			Customer customerFound = searchCustomer(customer.getCustId());
			if (customerFound !=null) {
				
				customerFound.setCustomerName(customer.getCustomerName());
				customerFound.setCity(customer.getCity());
				customerFound.setMobileNo(customer.getMobileNo());
				customerFound.setBillAmount(customer.getBillAmount());
				return "Customer Record Updated...";
			}
			return "Customer Record Not Exists...";
		}

	 
	 public String addCustomer(Customer customer) {
			customerList.add(customer);
			return "Customer Record Inserted...";
		}
	 
	 
	 public String deleteCustomer(int custId) {
			Customer customerFound = searchCustomer(custId);
			if (customerFound !=null) {
				customerList.remove(customerFound);
				return "Customer Record Deleted...";
			}
			return "Employ Record not Found...";
		}
}
