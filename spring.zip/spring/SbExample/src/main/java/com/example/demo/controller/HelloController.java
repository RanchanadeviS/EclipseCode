package com.example.demo.controller;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping(value="/hello")
@RestController
public class HelloController {
	
	@GetMapping(value="/test")
	public String sayHello()
	{
		return "Hello I'm Ranchanan Devi Sakthivel";
	}

	
	
	@GetMapping(value="/haeyyy")
	public String haeh()
	{
		return "Do not get distructed....";
	}
	
	
	
	
	@GetMapping(value="/greet/{name}")
	public String sayHello(@PathVariable String name)
	{
		return "Good morning.."+name;
	}
	
	@GetMapping(value="/do")
	public String Do()
	{
		return "do your work properly...";
	}
	
	
	@GetMapping(value="/greeting")
	public String greeting()
	{
		int hr=new Date().getHours();
		if(hr<12)
			return "good morning";
		else if(hr>=12 && hr < 16)
			return "Good Afternoon";
		else 
			return "good evening";
	}
}
